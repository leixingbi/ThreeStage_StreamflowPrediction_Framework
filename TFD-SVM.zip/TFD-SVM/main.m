% % Preparation
% % First: OPen the TFA_Toolboxes folder and right-click install_all_toolboxes
% % Sencond:To run make.m file (libsvm-mat-2.89-3[FarutoUltimate3.0] folder)
% % Modifiers and contact address: Xingbi Lei leixingbi@foxmail.com 
% % Software Platform: MATLAB R2018a win64  on Lenovo XiaoXin-15ARE 2020

clear all                            
clc
addpath(genpath('EWT'))
addpath(genpath('libsvm-mat-2.89-3[FarutoUltimate3.0]'))
%% 1.Read data
datamon  = xlsread('DATA.xls','E2:E661')'; 
dataMon  = datamon(:);         
data = dataMon;                            
[~,~,date] = xlsread('data.xls',1,'B2:B661'); 
date = datetime(date,'InputFormat','yyyy-MM');


%% 2.Training and test sets
rTrain = 0.8; % Partitioning ratio

len = length(data); 
lenTrain = round(rTrain*len);  
lenTest  = len - lenTrain;  
dataTrain = data(1:lenTrain);  
dataTest  = data(lenTrain+1:len); 
dateTest  = date(lenTrain+1:len); 

% % 3.Time-frequency decomposition method
% % 3.1 EMD
imf_EMD = kEMD(data);  
imf_EMD_Train = imf_EMD(:,1:lenTrain); 
imf_EMD_Test  = imf_EMD(:,lenTrain+1:len);
[imfNumEMD,~] = size(imf_EMD);
% % 3.2 EEMD
allmode=eemd(data,0.2,100)'; % Note:the first component is the original data
imf_EEMD = allmode(2:end,:); 
[imfNumEEMD,~] = size(imf_EEMD);

% % 3.3 EWT
imf_EWT = myEWT(data);
[imfNumEWT,~] = size(imf_EWT);
% % 3.4 VMD
[imf_VMD,~] = VMD(data,2000,0,8,0,1,1e-7); 
[imfNumVMD,~] = size(imf_VMD);


%% 4.Forecasting() 
order = 11 ;  % lag time

global lei_ga_count  % Record the times the GA algorithm is called 
lei_ga_count = 0;
global bestmse; % Objective function result
bestmse = [0,0,0,0,0,0,0,0,0,0,0];
global bestc;  % Parameter C of SVM  
bestc = [0,0,0,0,0,0,0,0,0,0,0]; 
global bestg;% Parameter G of SVM  
bestg = [0,0,0,0,0,0,0,0,0,0,0];
global ptesty
ptesty = [];

j = 1 % To avoid failure to run stand-alone SVM

% 4.0 SVM
for i = lenTrain+1:len 
    forDataSVM(i) = SVDforecastOne_ex(data(1:i-1),order,j);  
end

for i = 13:len 
    forDataSVM(i) = SVDforecastOne_ex(data(1:i-1),order,j);  
end

% % % 4.1 EMD-SVM
lei_ga_count = 0;
bestmse = [0,0,0,0,0,0,0,0,0,0,0];
bestc = [0,0,0,0,0,0,0,0,0,0,0]; 
bestg = [0,0,0,0,0,0,0,0,0,0,0];
ptesty = [];
for i = lenTrain+1:len  
    for j = 1:imfNumEMD 
        forDataEMD_SVM_temp(i,j) = SVDforecastOne_ex(imf_EMD(j,1:i-1),order,j);
    end
    forDataEMD_SVM(i) = sum(forDataEMD_SVM_temp(i,:)); 
end

for i = 13:len 
    for j = 1:imfNumEMD  
        forDataEMD_SVM_temp(i,j) = SVDforecastOne_ex(imf_EMD(j,1:i-1),order,j); 
    end
    forDataEMD_SVM(i) = sum(forDataEMD_SVM_temp(i,:)); 
end

% % 4.2 EEMD-SVM
lei_ga_count = 0;
bestmse = [0,0,0,0,0,0,0,0,0,0,0];
bestc = [0,0,0,0,0,0,0,0,0,0,0]; 
bestg = [0,0,0,0,0,0,0,0,0,0,0];
ptesty = [];
for i = lenTrain+1:len 
    for j = 1:imfNumEEMD  
        forDataEEMD_SVM_temp(i,j) = SVDforecastOne_ex(imf_EEMD(j,1:i-1),order,j);
    end
    forDataEEMD_SVM(i) = sum(forDataEEMD_SVM_temp(i,:)); 
end

for i = 13:len  
    for j = 1:imfNumEEMD 
        forDataEEMD_SVM_temp(i,j) = SVDforecastOne_ex(imf_EEMD(j,1:i-1),order,j); 
    end
    forDataEEMD_SVM(i) = sum(forDataEEMD_SVM_temp(i,:)); 
end
save("NPR_EEMDSVM.mat")

% % 4.3 EWT-SVM
lei_ga_count = 0;
bestmse = [0,0,0,0,0,0,0,0,0,0,0];
bestc = [0,0,0,0,0,0,0,0,0,0,0]; 
bestg = [0,0,0,0,0,0,0,0,0,0,0];
ptesty = [];
for i = lenTrain+1:len 
    for j = 1:imfNumEWT 
        forDataEWT_SVM_temp(i,j) = SVDforecastOne_ex(imf_EWT(j,1:i-1),order,j); 
    end
    forDataEWT_SVM(i) = sum(forDataEWT_SVM_temp(i,:));  
end

for i = 13:len  
    for j = 1:imfNumEWT 
        forDataEWT_SVM_temp(i,j) = SVDforecastOne_ex(imf_EWT(j,1:i-1),order,j);  
    end
    forDataEWT_SVM(i) = sum(forDataEWT_SVM_temp(i,:));  
end

% % 4.3 VMD-SVD
lei_ga_count = 0;
bestmse = [0,0,0,0,0,0,0,0,0,0,0];
bestc = [0,0,0,0,0,0,0,0,0,0,0]; 
bestg = [0,0,0,0,0,0,0,0,0,0,0];
ptesty = [];
for i = lenTrain+1:len  
    for j = 1:imfNumVMD 
        forDataVMD_SVM_temp(i,j) = SVDforecastOne_ex(imf_VMD(j,1:i-1),order,j);  
    end
    forDataVMD_SVM(i) = sum(forDataVMD_SVM_temp(i,:));  
end

for i = 13:len 
    for j = 1:imfNumVMD 
        forDataVMD_SVM_temp(i,j) = SVDforecastOne_ex(imf_VMD(j,1:i-1),order,j); 
    end
    forDataVMD_SVM(i) = sum(forDataVMD_SVM_temp(i,:)); 
end


% % 6.Calculate the performance RMSE/MAPE/NSE
RMSE_SVM = myRMSE(dataTest,forDataSVM(lenTrain+1:len))
MAPE_SVM = myMAPE(dataTest,forDataSVM(lenTrain+1:len))
NSE_SVM  = myNSE(dataTest,forDataSVM(lenTrain+1:len))

RMSE_EMD_SVM = myRMSE(dataTest,forDataEMD_SVM(lenTrain+1:len))
MAPE_EMD_SVM = myMAPE(dataTest,forDataEMD_SVM(lenTrain+1:len))
NSE_EMD_SVM  = myNSE(dataTest,forDataEMD_SVM(lenTrain+1:len))

RMSE_EEMD_SVM = myRMSE(dataTest,forDataEEMD_SVM(lenTrain+1:len))
MAPE_EEMD_SVM = myMAPE(dataTest,forDataEEMD_SVM(lenTrain+1:len))
NSE_EEMD_SVM  = myNSE(dataTest,forDataEEMD_SVM(lenTrain+1:len))

RMSE_EWT_SVM = myRMSE(dataTest,forDataEWT_SVM(lenTrain+1:len)) 
MAPE_EWT_SVM = myMAPE(dataTest,forDataEWT_SVM(lenTrain+1:len))
NSE_EWT_SVM  = myNSE(dataTest,forDataEWT_SVM(lenTrain+1:len))

RMSE_VMD_SVM = myRMSE(dataTest,forDataVMD_SVM(lenTrain+1:len)) 
MAPE_VMD_SVM = myMAPE(dataTest,forDataVMD_SVM(lenTrain+1:len))
NSE_VMD_SVM  = myNSE(dataTest,forDataVMD_SVM(lenTrain+1:len))
save("NPR_ALL.mat")
disp("Finish!")

% % Output results to excel file
xlswrite("NPR_discussion.xlsx",data,'sheet1') 
xlswrite("NPR_discussion.xlsx",forDataSVM,'sheet2')
xlswrite("NPR_discussion.xlsx",forDataEMD_SVM,'sheet3') 
xlswrite("NPR_discussion.xlsx",forDataEEMD_SVM,'sheet4') 
xlswrite("NPR_discussion.xlsx",forDataEWT_SVM,'sheet5') 
xlswrite("NPR_discussion.xlsx",forDataVMD_SVM,'sheet6') 
xlswrite("NPR_discussion.xlsx",forDataEMD_SVM_temp,'sheet7') 
xlswrite("NPR_discussion.xlsx",forDataEEMD_SVM_temp,'sheet8')
xlswrite("NPR_discussion.xlsx",forDataEWT_SVM_temp,'sheet9') 
xlswrite("NPR_discussion.xlsx",forDataVMD_SVM_temp,'sheet10') 
