function mse = myamape(a,b)
    a = a(:);
    b = b(:);
    mape = sum(abs((a-b)./a))/length(a);
end