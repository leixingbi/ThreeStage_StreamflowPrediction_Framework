function mse = myMSE(a,b)
    a = a(:);
    b = b(:);
    mse = sum((a-b).^2)/length(a);
end