function mse = myRMSE(a,b)
    a = a(:);
    b = b(:);
    mse = sqrt(sum((a-b).^2)/length(a));
end