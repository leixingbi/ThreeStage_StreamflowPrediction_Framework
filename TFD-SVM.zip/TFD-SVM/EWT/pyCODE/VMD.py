import vmdpy
u, u_hat, omega =
