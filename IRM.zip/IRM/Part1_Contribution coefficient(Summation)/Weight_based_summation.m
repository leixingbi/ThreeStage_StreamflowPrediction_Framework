%% First:Load variable files (NRR_all.mat)

clear reconbine1
global IMF_SVM_temp m dataTrain1 reconbine1  reconbine2  

%% --Replace each time with the corresponding hybrid model 

IMF_SVM_temp = forDataEWT_SVM_temp;  % hybrid model
dataTrain1 = dataTrain;

%% ----------------------

IMF_SVM_temp = IMF_SVM_temp';
[m,~] = size(IMF_SVM_temp);
numberOfVariables = m; 
size(IMF_SVM_temp);
if m == 8
    lb = [0, 0, 0, 0, 0, 0, 0, 0];
    ub = [1, 1, 1, 1, 1, 1, 1, 1];
else
    if m == 9
        lb = [0, 0, 0, 0, 0, 0, 0, 0, 0];
        ub = [1, 1, 1, 1, 1, 1, 1, 1, 1];
    end
end       
% rng default % For reproducibility 
FitnessFunction = @obj; 

% global reconbine1 reconbine2 k
% reconbine1 = IMF_SVM_temp;

%% GA
% options = optimoptions('ga','InitialPopulation',[1,1,1,1,1,1,1,1],'PopulationSize',200,...
%     'InitialScores',[14.6259],'InitialPenalty', 1,'MigrationInterval',1,'CrossoverFraction', 0.2, ...
%     'MigrationFraction',0.9);
% options = optimoptions(@ga,',);
[x,fval,exitFlag,output,population,scores] = ga(FitnessFunction,numberOfVariables,[],[],[],[],lb,ub,[],[]) % GA�㷨�Ż�

% %% PSO
% options = optimoptions('particleswarm','SwarmSize',100);
% [x,fval,exitflag,output] = particleswarm(FitnessFunction,numberOfVariables,lb,ub)


origin_msvr = sum(IMF_SVM_temp);
reconbine = IMF_SVM_temp;
for i =1:m
    reconbine(i,:) = reconbine(i,:) * x(i);     
end
reconbine = sum(reconbine); 
result(1) = myMAPE(dataTest(1:132),reconbine(529:660));
result(2) = myRMSE(dataTest(1:132),reconbine(529:660));
result(3) = myNSE(dataTest(1:132),reconbine(529:660))

comparison(1) = fval;
comparison(2) = myRMSE(dataTrain(13:528),reconbine(13:528));
comparison(3) = myRMSE(dataTrain(13:528),origin_msvr(13:528))
function y = obj(x)  
global IMF_SVM_temp m dataTrain1  reconbine1 reconbine2      
    reconbine1 = IMF_SVM_temp;
    for i =1:m
        reconbine1(i,:) = reconbine1(i,:) * x(i);     
    end
    reconbine2 = sum(reconbine1);
    y = myRMSE(dataTrain1(13:528),reconbine2(13:528));
end