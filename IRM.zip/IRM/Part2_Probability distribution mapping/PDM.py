import numpy as np
import pandas as pd
from scipy import stats
"""
Modifiers and contact address: Xingbi Lei leixingbi@foxmail.com 
Software Platform: Python3.8 on window 10 (Lenovo XiaoXin-15ARE 2020)
"""

# ----------------Variable assignment-----------------------------------
excel_file = "data.xls"

df = pd.read_excel(excel_file, sheet_name="Sheet3")  
total_column = 660   
station_name = "data"   
ecmwf_name = "vmdsvmga"  
# -------------------------------------------------------------


station0 = df.loc[[i for i in range(12, total_column, 1)], [station_name]]  #
ecmwf0 = df.loc[[i for i in range(12, total_column, 1)], [ecmwf_name]]

station_value = station0.values.flatten() 
ecmwf_value = ecmwf0.values.flatten()


# ----------------QM---------------------------------
max_station = np.max(station_value)
min_station = np.min(station_value)
max_ecmwf = np.max(ecmwf_value)
min_ecmwf = np.min(ecmwf_value)

sub_group_station = np.linspace(min_station, max_station, 100) 
sub_group_ecmwf = np.linspace(min_ecmwf, max_ecmwf, 100)

station_value_sort = np.sort(station_value)
ecmwf_value_sort = np.sort(ecmwf_value)
PDF_station = np.zeros(100)
PDF_ecmwf = np.zeros(100)


for i in range(len(station_value)):
    for j in range(100):
        if station_value[i] <= sub_group_station[j]:
            PDF_station[j] = PDF_station[j] + (1/total_column)

for i in range(len(ecmwf_value)):
    for j in range(100):
        if ecmwf_value[i] <= sub_group_ecmwf[j]:
            PDF_ecmwf[j] = PDF_ecmwf[j] + (1/total_column)

errect_ecmwf = np.zeros(len(station_value))



for i in range(len(ecmwf_value)):
    for j in range(100):
        if ecmwf_value[i] <= sub_group_ecmwf[j]:
            if j != 0:
                position = (ecmwf_value[i]-sub_group_ecmwf[j-1])/(sub_group_ecmwf[j]-sub_group_ecmwf[j-1])
                value_pdf = PDF_ecmwf[j-1] + ((PDF_ecmwf[j]-PDF_ecmwf[j-1])*position)
            else:
                value_pdf = PDF_ecmwf[0]
            for z in range(100):
                if value_pdf <= PDF_station[z]:
                    if  z != 0:
                        position_errect = (value_pdf-PDF_station[z-1])/(PDF_station[z]-PDF_station[z-1])
                        errect_ecmwf[i] = sub_group_station[z-1] + ((sub_group_station[z] - sub_group_station[z-1]) * position_errect)
                    else:
                        errect_ecmwf[i] = sub_group_station[0]
                    break
            break
print(errect_ecmwf)
result_file = open(r"result.txt", 'w', encoding='UTF-8')

for i in errect_ecmwf:
    result_file.write(str(i)+"\n")
result_file.close()

sub_group_station_file = open(r"sub_group_station.txt", 'w', encoding='UTF-8')
PDF_station_file = open(r"PDF_station.txt", 'w', encoding='UTF-8')
sub_group_ecmwf_file = open(r"sub_group_ecmwf.txt", 'w', encoding='UTF-8')
PDF_ecmwf_file = open(r"PDF_ecmwf.txt", 'w', encoding='UTF-8')

for i in range(100):
    sub_group_ecmwf_file.write(str(sub_group_ecmwf[i])+"\n")
    sub_group_station_file.write(str(sub_group_station[i])+"\n")
    PDF_station_file.write(str(PDF_station[i])+"\n")
    PDF_ecmwf_file.write(str(PDF_ecmwf[i])+"\n")

sub_group_station_file.close()
sub_group_ecmwf_file.close()
PDF_ecmwf_file.close()
PDF_station_file.close()

# --------------- Finish QM -----------------
# --------------- Calculate performance index-------------------
MSWEP_DATA = ecmwf_value
True_mea = station_value


# NSE
NSE0 = 0
K1 = 0
K2 = 0
mean_true = np.mean(True_mea)
for j in range(len(True_mea)):
    K1 = K1 + ((True_mea[j]-MSWEP_DATA[j])*(True_mea[j]-MSWEP_DATA[j]))
    K2 = K2 + ((True_mea[j]-mean_true)*(True_mea[j]-mean_true))
NSE = 1 - (K1/K2)
print("NSE=", NSE)

# RMSE
K1 = 0
for j in range(len(True_mea)):
    K1 = K1 + ((True_mea[j]-MSWEP_DATA[j])*(True_mea[j]-MSWEP_DATA[j]))
RMSE = np.sqrt(K1/len(True_mea))
print("RMSE=", RMSE)

# MAPE
K1 = 0
for j in range(len(True_mea)):
    if True_mea[j] == 0:
        continue
    K1 = np.abs(((True_mea[j]-MSWEP_DATA[j])/(True_mea[j])))*100 + K1

MAPE = K1/len(True_mea)
print("MAPE", MAPE)

